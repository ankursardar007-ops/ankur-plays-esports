import {MetadataRoute} from 'next'
export default function sitemap():MetadataRoute.Sitemap{return [{url:'http://localhost:3000/'},{url:'http://localhost:3000/tournaments'},{url:'http://localhost:3000/leaderboard'},{url:'http://localhost:3000/results'},{url:'http://localhost:3000/rules'},{url:'http://localhost:3000/registration'}]}
