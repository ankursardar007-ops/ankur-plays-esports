import Link from 'next/link'
import TournamentCard from '@/components/TournamentCard'
import { supabaseServer } from '@/lib/server'
export default async function Home(){
 const {data}=await supabaseServer().from('tournaments').select('*').eq('published',true).in('status',['upcoming','live']).order('start_at').limit(6)
 const {data:winners}=await supabaseServer().from('results').select('*').order('created_at',{ascending:false}).limit(3)
 return <><section className="hero"><div className="container"><div className="eyebrow">ANKUR PLAYS · ESPORTS</div><h1>FREE FIRE <span>TOURNAMENTS</span></h1><p className="lead">Join tournaments, compete with players and win exciting prizes.</p><div className="actions"><Link className="btn btn-primary" href="/tournaments">Join Tournament</Link><Link className="btn btn-secondary" href="/tournaments">View Tournaments</Link></div></div></section>
 <section className="section"><div className="container"><div className="section-head"><div><h2>Featured / Upcoming</h2><p>Pick your next battle.</p></div><Link href="/tournaments" className="btn btn-secondary">View all</Link></div><div className="grid">{data?.map(t=><TournamentCard key={t.id} t={t}/>)}</div></div></section>
 <section className="section"><div className="container"><div className="section-head"><div><h2>Recent Winners</h2><p>Champions from the latest battles.</p></div></div><div className="winners">{winners?.map((w:any)=><div className="winner" key={w.id}><h3>{w.tournament_name}</h3><p className="muted">{w.winner_team} · {w.date}</p><div className="prize">₹{w.prize}</div></div>)}</div></div></section>
 <section className="section"><div className="container"><div className="section-head"><div><h2>How It Works</h2><p>Six simple steps from registration to victory.</p></div></div><div className="steps">{['Choose a tournament','Register your team','Complete payment','Get approval','Join the match','Win prizes'].map((x,i)=><div className="step" key={x}><b>0{i+1}</b><span>{x}</span></div>)}</div></div></section></>
}
