import './globals.css'
import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
export const metadata={title:'Ankur Plays eSports Tournament',description:'Free Fire and Free Fire MAX esports tournaments.'}
export default function RootLayout({children}:{children:React.ReactNode}){return <><Nav/><main>{children}</main><Footer/></>}
