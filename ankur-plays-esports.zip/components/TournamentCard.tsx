import Link from 'next/link'
import { Tournament } from '@/lib/types'
export default function TournamentCard({t}:{t:Tournament}){return <article className="card">
 <div className="banner"><span className={`badge ${t.status}`}>{t.status}</span></div>
 <div className="card-body"><h3>{t.name}</h3><p className="muted">{new Date(t.start_at).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})} · {new Date(t.start_at).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}</p>
 <div className="meta"><div><small>Entry</small><b>₹{t.entry_fee}</b></div><div><small>Prize Pool</small><b className="price">₹{t.prize_pool}</b></div><div><small>Slots</small><b>{t.total_slots}</b></div><div><small>Available</small><b>{Math.max(0,t.total_slots - (t as any).filled_slots)}</b></div></div>
 <div className="actions"><Link className="btn btn-secondary" href={`/tournaments/${t.id}`}>View Details</Link>{t.status==='upcoming'&&<Link className="btn btn-primary" href={`/registration?tournament=${t.id}`}>Register Now</Link>}</div>
 </div></article>}
