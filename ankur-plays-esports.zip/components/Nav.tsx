import Link from 'next/link'
export default function Nav(){
 return <nav className="nav"><div className="container navin">
  <Link className="brand" href="/">ANKUR <span>PLAYS</span></Link>
  <div className="links"><Link href="/tournaments">Tournaments</Link><Link href="/leaderboard">Leaderboard</Link><Link href="/results">Results</Link><Link href="/rules">Rules</Link><Link href="/registration">My Registration</Link></div>
  <Link className="btn btn-primary" href="/tournaments">Play Now</Link>
 </div></nav>
}
