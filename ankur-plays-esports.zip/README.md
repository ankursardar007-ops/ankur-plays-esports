# Ankur Plays eSports Tournament

A production-oriented Free Fire / Free Fire MAX tournament management platform built with Next.js, TypeScript, Supabase, and responsive CSS.

## Included
- Public home, tournaments, details, registration, registration lookup, leaderboard, results, rules
- Admin email/password authentication through Supabase Auth
- Admin tournament CRUD, publish/unpublish, registrations, payment verification, room release, leaderboard and results management
- Supabase PostgreSQL schema + Row Level Security
- UPI payment fields and screenshot storage
- Duplicate-registration protection
- Private room credentials only returned for approved registrations after release/live status
- Search by tournament, registration ID, and team
- Notification records
- SEO metadata and mobile-first UI

## Setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL editor.
3. In Supabase Storage, the SQL creates a `payment-screenshots` bucket and policies.
4. Create an admin user in Supabase Authentication > Users.
5. Run the SQL below after creating the user, replacing the email:
   `select public.make_admin('admin@example.com');`
6. Copy `.env.example` to `.env.local` and fill in your Supabase URL and anon key.
7. Install and run:
   `npm install`
   `npm run dev`

## Production
Deploy to Vercel or another Node-compatible host. Add the same environment variables there. Use a custom domain and configure your social/payment settings in the admin/database.

## Important
Payment screenshots are evidence only. The application never auto-approves payments from screenshots. Admins must explicitly mark payments approved/rejected.

Room credentials are never rendered on public tournament pages. The registration lookup endpoint only returns them when the registration is approved and the tournament is live or `room_released` is true.
