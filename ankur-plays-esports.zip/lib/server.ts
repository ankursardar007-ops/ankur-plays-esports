import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
export function supabaseServer(){
 const cookieStore=cookies()
 return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{cookies:{getAll(){return cookieStore.getAll()},setAll(){}}})
}
