export type Tournament = {
  id: string; name: string; banner_url?: string | null; start_at: string;
  entry_fee: number; prize_pool: number; total_slots: number; registration_deadline?: string | null;
  match_format?: string | null; rules?: string | null; status: 'upcoming'|'live'|'completed';
  published: boolean; room_id?: string | null; room_password?: string | null; room_released: boolean;
  upi_id?: string | null; upi_qr_url?: string | null;
}
export type Registration = {
  id: string; registration_code: string; team_name: string; leader_name: string; game_uid: string;
  whatsapp: string; tournament_id: string; registration_status: string; approval_status: string;
  created_at: string; payment?: { status: string; transaction_id: string; screenshot_url?: string | null }[];
  tournaments?: Tournament;
}
