
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('admin','user')),
  created_at timestamptz not null default now()
);

create table if not exists tournaments (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  banner_url text,
  start_at timestamptz not null,
  entry_fee numeric(10,2) not null default 0,
  prize_pool numeric(10,2) not null default 0,
  total_slots integer not null check(total_slots > 0),
  registration_deadline timestamptz,
  match_format text,
  rules text,
  status text not null default 'upcoming' check(status in ('upcoming','live','completed')),
  published boolean not null default false,
  room_id text,
  room_password text,
  room_released boolean not null default false,
  upi_id text,
  upi_qr_url text,
  created_at timestamptz not null default now()
);

create table if not exists teams (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  leader_name text not null,
  game_uid text not null,
  whatsapp text not null,
  created_at timestamptz not null default now()
);

create table if not exists registrations (
  id uuid primary key default gen_random_uuid(),
  registration_code text unique not null,
  tournament_id uuid not null references tournaments(id) on delete cascade,
  team_id uuid not null references teams(id) on delete cascade,
  registration_status text not null default 'submitted' check(registration_status in ('submitted','confirmed','cancelled')),
  approval_status text not null default 'pending' check(approval_status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  unique(tournament_id, team_id)
);

create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid unique not null references registrations(id) on delete cascade,
  amount numeric(10,2) not null default 0,
  transaction_id text not null,
  screenshot_path text,
  status text not null default 'pending' check(status in ('pending','approved','rejected')),
  verified_by uuid references auth.users(id),
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists leaderboards (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid references tournaments(id) on delete cascade,
  team_name text not null,
  matches integer not null default 0,
  booyah integer not null default 0,
  kills integer not null default 0,
  placement_points integer not null default 0,
  kill_points integer not null default 0,
  total_points integer generated always as (placement_points + kill_points) stored,
  prize numeric(10,2) not null default 0,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists results (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid references tournaments(id) on delete cascade,
  tournament_name text not null,
  date text not null,
  winner_team text not null,
  runner_up text,
  prize numeric(10,2) not null default 0,
  result_image_url text,
  created_at timestamptz not null default now()
);

create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  registration_id uuid references registrations(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

create or replace function public.make_admin(p_email text)
returns void language plpgsql security definer set search_path = public
as $$ declare uid uuid; begin select id into uid from auth.users where email=p_email; if uid is null then raise exception 'User not found'; end if; insert into public.profiles(id,role) values(uid,'admin') on conflict(id) do update set role='admin'; end $$;

create or replace function public.create_registration(
 p_tournament_id uuid,p_team_name text,p_leader_name text,p_game_uid text,p_whatsapp text,
 p_transaction_id text,p_screenshot_path text
) returns jsonb language plpgsql security definer set search_path=public
as $$
declare tid uuid; rid uuid; code text; fee numeric;
begin
 if not exists(select 1 from tournaments where id=p_tournament_id and published=true and status='upcoming') then raise exception 'Tournament is not accepting registrations'; end if;
 if exists(select 1 from registrations r join teams tm on tm.id=r.team_id where r.tournament_id=p_tournament_id and tm.game_uid=p_game_uid) then raise exception 'This Game UID is already registered'; end if;
 select entry_fee into fee from tournaments where id=p_tournament_id;
 insert into teams(name,leader_name,game_uid,whatsapp) values(p_team_name,p_leader_name,p_game_uid,p_whatsapp) returning id into tid;
 code := 'AP-'||lpad(nextval('registration_code_seq')::text,6,'0');
 insert into registrations(registration_code,tournament_id,team_id) values(code,p_tournament_id,tid) returning id into rid;
 insert into payments(registration_id,amount,transaction_id,screenshot_path) values(rid,fee,p_transaction_id,p_screenshot_path);
 return jsonb_build_object('registration_id',rid,'registration_code',code);
exception when unique_violation then raise exception 'Duplicate registration';
end $$;

create sequence if not exists registration_code_seq start 123;

create or replace function public.lookup_registration(p_code text)
returns table(registration_code text,team_name text,leader_name text,game_uid text,tournament_name text,payment_status text,approval_status text,room_visible boolean,room_id text,room_password text)
language sql security definer set search_path=public
as $$
 select r.registration_code,tm.name,tm.leader_name,tm.game_uid,t.name,p.status,r.approval_status,
 (r.approval_status='approved' and (t.status='live' or t.room_released)) as room_visible,
 case when r.approval_status='approved' and (t.status='live' or t.room_released) then t.room_id else null end,
 case when r.approval_status='approved' and (t.status='live' or t.room_released) then t.room_password else null end
 from registrations r join teams tm on tm.id=r.team_id join tournaments t on t.id=r.tournament_id
 join payments p on p.registration_id=r.id
 where upper(r.registration_code)=upper(p_code);
$$;

alter table profiles enable row level security;
alter table tournaments enable row level security;
alter table teams enable row level security;
alter table registrations enable row level security;
alter table payments enable row level security;
alter table leaderboards enable row level security;
alter table results enable row level security;
alter table notifications enable row level security;

create policy "public read published tournaments" on tournaments for select using (published=true or public.is_admin());
create policy "admins manage tournaments" on tournaments for all using(public.is_admin()) with check(public.is_admin());

create policy "admins read registrations" on registrations for select using(public.is_admin());
create policy "admins update registrations" on registrations for update using(public.is_admin()) with check(public.is_admin());

create policy "admins read teams" on teams for select using(public.is_admin());
create policy "admins read payments" on payments for select using(public.is_admin());
create policy "admins update payments" on payments for update using(public.is_admin()) with check(public.is_admin());

create policy "public read published leaderboard" on leaderboards for select using(published=true or public.is_admin());
create policy "admins manage leaderboard" on leaderboards for all using(public.is_admin()) with check(public.is_admin());

create policy "public read results" on results for select using(true);
create policy "admins manage results" on results for all using(public.is_admin()) with check(public.is_admin());

create policy "admins manage profiles" on profiles for all using(public.is_admin()) with check(public.is_admin());
create policy "own profile read" on profiles for select using(id=auth.uid());

create policy "admins read notifications" on notifications for select using(public.is_admin() or user_id=auth.uid());

insert into tournaments(name,start_at,entry_fee,prize_pool,total_slots,registration_deadline,match_format,rules,status,published,upi_id)
values
('Ankur Clash #01', now()+interval '3 days',20,500,12,now()+interval '2 days','Squad · Single Match','Standard rules apply.','upcoming',true,'ankurplays@upi'),
('Ankur Battle #02', now()+interval '6 days',30,1000,24,now()+interval '5 days','Squad · Best of 2','Standard rules apply.','upcoming',true,'ankurplays@upi')
on conflict do nothing;

insert into results(tournament_name,date,winner_team,runner_up,prize)
values('Ankur Clash Demo','25 Aug 2026','Demo Warriors','Fire Kings',500)
on conflict do nothing;

create or replace function public.storage_path_is_safe(path text)
returns boolean language sql immutable as $$ select path !~ '\.\.' and path !~ '^/' $$;

insert into storage.buckets(id,name,public) values('payment-screenshots','payment-screenshots',false) on conflict(id) do nothing;

create policy "authenticated admins can upload payment screenshots" on storage.objects for insert to authenticated with check(bucket_id='payment-screenshots' and public.is_admin());
create policy "admins can read payment screenshots" on storage.objects for select to authenticated using(bucket_id='payment-screenshots' and public.is_admin());
